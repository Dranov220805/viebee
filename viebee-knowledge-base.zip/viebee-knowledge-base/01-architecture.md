# 01 — System Architecture & Topology 🏛️

VieBee employs a decoupled, enterprise architecture designed to support both autonomous frontend prototyping (via browser storage) and high-scale production deployment (via NestJS and PostgreSQL).

```
┌────────────────────────────────────────────────────────────────────────┐
│                        VieBee System Topology                          │
└────────────────────────────────────────────────────────────────────────┘

 [ Client Browser: Next.js 16 (React 19) ]
   ├── Presentation Layer (Tailwind v4 + Ant Design v6 + Framer Motion)
   ├── State Management (Redux Toolkit store)
   └── Data Access Layer:
        ├── Production Mode: Axios HTTP Client ──> [ NestJS 11 API (Port 4000) ]
        └── Prototype Mode: mockHttpAdapter   ──> [ LocalStorage / SessionStorage ]

 [ Backend API: NestJS 11 (Clean Architecture) ]
   ├── HttpApi Layer (Controllers, Guards, Interceptors, Swagger OpenAPI)
   ├── Application Layer (DTOs, Validation Pipes, Use-Case Services)
   ├── Domain Core (Entities, Enums, Business Rules, BusinessExceptions)
   └── Infrastructure Layer:
        ├── Prisma ORM ──> [ PostgreSQL Database (Port 5432) ]
        └── LangChain AI Engine ──> [ OpenAI / RAG Embeddings Proxy ]
```

---

## 1. Frontend Subsystem (`viebee/`)

- **Framework:** Next.js 16 (App Router) + React 19 + TypeScript 5.
- **UI & Design Tokens:**
  - **Ant Design v6:** For accessible, complex components (Modals, Selects, Drawers, Steps, Tables).
  - **Tailwind CSS v4:** For layout, responsive design, and heritage micro-animations.
  - **Cultural Palette:** Honey Gold (`#f59e0b`, `#d97706`), Terracotta Cinnabar (`#c2410c`), Deep Vietnamese Indigo (`#1e1b4b`), Warm Rice Paper Cream (`#fdfbf7`).
- **Autonomous Mock Adapter:**
  - Located at `src/@core/http/mock-adapter.ts`.
  - Persists workshops, RSVPs, copilot chat history, and active user profiles in `localStorage` without requiring the NestJS backend to be running.
  - Returns identical `{ status, statusCode, message, data }` response envelopes.

---

## 2. Backend Subsystem (`backend/`)

- **Framework:** NestJS 11 + TypeScript + Express.
- **Layered Clean Architecture:**
  - **`domain/`**: Pure TypeScript entities and repository contracts. No framework dependencies.
  - **`application/`**: Use cases (create workshop, reserve RSVP, query AI copilot) and class-validator DTOs.
  - **`infrastructure/`**: Prisma repositories for PostgreSQL, SQLite local fallback, LangChain RAG vector lookup.
  - **`http-api/`**: Thin presentation controllers with Swagger OpenAPI decorators, `TransformResponseInterceptor`, and `HttpExceptionFilter`.
